export type DetailMessageType = {
  message: string;
  details?: [{ messages: string }];
}
