export const BASE_URL = 'https://camera-shop.accelerator.htmlacademy.pro/';

export const SERVER_TIMEOUT = 5000;
export const ERROR_TIMEOUT = 3000;
