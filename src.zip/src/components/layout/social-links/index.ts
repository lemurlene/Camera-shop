import { SocialLinksMemo } from './social-links';
export default SocialLinksMemo;
