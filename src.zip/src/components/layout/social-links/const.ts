export const SOCIAL_LINKS = [
  { href: '#',
    ariaLabel: 'Переход на страницу вконтатке',
    icon: '#icon-vk' },
  { href: '#',
    ariaLabel: 'Переход на страницу pinterest',
    icon: '#icon-pinterest' },
  { href: '#',
    ariaLabel: 'Переход на страницу reddit',
    icon: '#icon-reddit' },
];
