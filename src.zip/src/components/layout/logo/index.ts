import LogoMemo from './logo';
export default LogoMemo;
