export type LogoConfigType = {
  logoClass: string;
  logoImg: string;
}
