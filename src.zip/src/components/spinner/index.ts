import SpinnerMemo from './spinner';
export default SpinnerMemo;
