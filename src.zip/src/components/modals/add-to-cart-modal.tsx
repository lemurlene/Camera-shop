import React from 'react';
import { Modal } from './modal';
import { useModal } from '../../contexts';
import ButtonAddBasketMemo from '../buttons/add-basket';
import { FullOfferType } from '../../const/type';

interface AddToCartModalProps {
  productData: FullOfferType;
}

export const AddToCartModal: React.FC<AddToCartModalProps> = ({ productData }) => {
  const { closeModal } = useModal();

  return (
    <Modal onClose={closeModal}>
      <p className="title title--h4">Добавить товар в корзину</p>
      <div className="basket-item basket-item--short">
        <div className="basket-item__img">
          <picture>
            <source
              type="image/webp"
              srcSet={`${productData.previewImgWebp}, ${productData.previewImgWebp2x} 2x`}
            />
            <img
              src={productData.previewImg}
              srcSet={`${productData.previewImg2x} 2x`}
              width="140"
              height="120"
              alt={productData.name}
            />
          </picture>
        </div>
        <div className="basket-item__description">
          <p className="basket-item__title">{productData.name}</p>
          <ul className="basket-item__list">
            <li className="basket-item__list-item">
              <span className="basket-item__article">Артикул:</span>
              <span className="basket-item__number">{productData.vendorCode}</span>
            </li>
            <li className="basket-item__list-item">{productData.type} {productData.category.toLowerCase()}</li>
            <li className="basket-item__list-item">{productData.level} уровень</li>
          </ul>
          <p className="basket-item__price">
            <span className="visually-hidden">Цена:</span>
            {productData.price.toLocaleString()} ₽
          </p>
        </div>
      </div>
      <div className="modal__buttons">
        <ButtonAddBasketMemo isModal />
      </div>
    </Modal>
  );
};
