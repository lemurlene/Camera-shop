export type ModalType = 'add-to-cart' | 'success' | 'delete';
