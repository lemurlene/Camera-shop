import RateMemo from './rate';
export default RateMemo;
