import ErrorMessage from './error-message';

export default ErrorMessage;
