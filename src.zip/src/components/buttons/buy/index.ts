import ButtonBuyMemo from './button-buy';
export default ButtonBuyMemo;
