export const ButtonAddBasketConfig = {
  Buy: {
    buttonClass: ' btn--purple',
    buttonModalClass: ' modal__btn modal__btn--fit-width',
    buttonText: 'Добавить в корзину',
    buttonIcon: (
      <svg width="24" height="16" aria-hidden="true">
        <use xlinkHref="#icon-add-basket"> </use>
      </svg>
    ),
  },
  InCart: {
    buttonClass: ' btn--purple-border product-card__btn--in-cart',
    buttonModalClass: ' modal__btn modal__btn--fit-width',
    buttonText: 'Перейти в корзину',
    buttonIcon: (
      <svg width="24" height="16" aria-hidden="true">
        <use xlinkHref="#icon-basket"> </use>
      </svg>
    )
  }
};
