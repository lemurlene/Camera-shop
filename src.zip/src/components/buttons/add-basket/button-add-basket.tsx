import { memo, useMemo } from 'react';
import cn from 'classnames';
import { ButtonAddBasketConfig } from './const';

type ButtonAddBasketProps = {
  isInCart?: boolean;
  isModal?: boolean;
}

function ButtonAddBasket({ isInCart = false, isModal = false }: ButtonAddBasketProps): JSX.Element {

  const { buttonClass, buttonText, buttonIcon, buttonModalClass } = useMemo(() => (
    isInCart ? ButtonAddBasketConfig.InCart : ButtonAddBasketConfig.Buy
  ), [isInCart]);

  const buttonClasses = cn(
    'btn btn--purple',
    buttonClass,
    {
      [buttonModalClass]: isModal && buttonModalClass
    }
  );

  return (
    <button
      className={buttonClasses}
      type="button"
    >
      {buttonIcon}
      {buttonText}
    </button >
  );
}

const ButtonAddBasketMemo = memo(ButtonAddBasket);

export default ButtonAddBasketMemo;
