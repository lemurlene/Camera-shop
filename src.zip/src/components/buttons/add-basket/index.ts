import ButtonAddBasketMemo from './button-add-basket';
export default ButtonAddBasketMemo;
