import СatalogFiltersMemo from './catalog-filters';
export default СatalogFiltersMemo;
