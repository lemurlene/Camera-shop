import BannerPromo from './banner-promo';
export default BannerPromo;
