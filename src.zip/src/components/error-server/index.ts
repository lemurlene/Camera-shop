import ErrorServer from './error-server';

export default ErrorServer;
