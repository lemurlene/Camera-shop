import { InitialStateType } from './type';

export const initialState: InitialStateType = {
  offers: [],
  isLoadingOffers: false,
  isErrorConnectionOffers: false,
};
