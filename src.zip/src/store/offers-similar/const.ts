import { InitialStateType } from './type';

export const initialState: InitialStateType = {
  offersSimilar: [],
  isLoadingOffersSimilar: false,
  isErrorConnectionOffers: false,
};
