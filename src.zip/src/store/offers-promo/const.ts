import { InitialStateType } from './type';

export const initialState: InitialStateType = {
  offersPromo: [],
  isLoadingOffersPromo: false,
  isErrorConnectionOffers: false,
};
