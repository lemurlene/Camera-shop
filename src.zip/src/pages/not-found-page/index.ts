import NotFoundPage from './not-found-page';
export default NotFoundPage;
