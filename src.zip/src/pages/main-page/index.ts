import MainPage from './main-page';

export default MainPage;
