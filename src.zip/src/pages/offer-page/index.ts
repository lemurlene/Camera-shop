import OfferPage from './offer-page';
export default OfferPage;
