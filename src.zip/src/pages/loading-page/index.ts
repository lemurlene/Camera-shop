import LoadingPage from './loading-page';
export default LoadingPage;
